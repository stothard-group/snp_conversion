# SNP Conversion

- FILE: SNP_conversion.py
- AUTH: Emily Herman (eherman@ualberta.ca)
- DATE: APR 7, 2020
- VERS: 2.0

Please see the [snp_conversion wiki](https://github.com/stothard-group/snp_conversion/wiki)